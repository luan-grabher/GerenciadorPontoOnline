<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-12 mx-auto mt-3">
        <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="text-center mt-2 col-6 mx-auto">
            <h3><?php echo e($title??"Consultar"); ?></h3>
            <hr class="">
        </div>
        <?php echo Form::open(['class'=>'form form-loadable form-inline col-10 mx-auto justify-content-center']); ?>

        <div class="form-group m-1 align-content-center">
            <label><b>Inicio: </b></label>
            <?php echo Form::date('inicio',now(),['class'=>'form-control']); ?>

        </div>
        <div class="form-group m-1 align-content-center">
            <label><b>Fim: </b></label>
            <?php echo Form::date('fim',now(),['class'=>'form-control']); ?>

        </div>
        <div>
            <?php echo Form::submit('Procurar',['class'=>'btn btn-primary']); ?>

        </div>
        <?php echo Form::close(); ?>


        <div class="col-12 mx-auto" id="results">
            <hr class="">
            <?php if(isset($filters)): ?>
                <div id="filters" class="col-10 mx-auto text-center">
                    <h5 class="font-weight-bold">Filtros Utilizados:</h5>
                    <?php if(isset($filters['dates'])): ?>
                        Inicio: <?php echo e($filters['dates']['start']); ?>

                        |
                        Fim: <?php echo e($filters['dates']['end']); ?>

                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <?php if(isset($results)): ?>
                <?php echo e(view('layouts.table',['data'=>$results])); ?>

            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.onlyhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/consult/erp/vendas.blade.php ENDPATH**/ ?>