<?php $__env->startSection('content'); ?>
<?php echo Form::open(); ?>

<div class="form-group">
    <?php echo Form::label('Inicio:'); ?>

    <?php echo Form::date('inicio', \Carbon\Carbon::now(),['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::label('Fim:'); ?>

    <?php echo Form::date('fim', \Carbon\Carbon::now(),['class'=>'form-control']); ?>

</div>
<div class="form-group">
    <?php echo Form::submit('Importar',['class'=>'btn btn-success']); ?>

</div>
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.onlyhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/import/pagarme/index.blade.php ENDPATH**/ ?>