<?php echo $__env->make('loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="col-12 mx-auto mt-3">
    <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="text-center mt-2 col-6 mx-auto">
        <h3><?php echo e($title??""); ?></h3>
        <hr class="">
    </div>
    <?php echo Form::open(['class'=>'form form-loadable form-inline col-10 mx-auto justify-content-center']); ?>

    <div class="form-group m-1 align-content-center">
        <label><b>Inicio: </b></label>
        <?php echo Form::date('inicio',now(),['class'=>'form-control']); ?>

    </div>
    <div class="form-group m-1 align-content-center">
        <label><b>Fim: </b></label>
        <?php echo Form::date('fim',now(),['class'=>'form-control']); ?>

    </div>
    <div>
        <?php echo Form::submit(($button_name??"Procurar"),['class'=>'btn btn-primary']); ?>

    </div>
    <?php echo Form::close(); ?>

</div>
<?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/layouts/forms/searchInRange.blade.php ENDPATH**/ ?>