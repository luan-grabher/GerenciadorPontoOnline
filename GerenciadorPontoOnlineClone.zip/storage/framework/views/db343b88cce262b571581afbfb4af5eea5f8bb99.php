<?php $__env->startSection('importName'); ?>
    Pagarme Recebimentos
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.import', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/import/pagarme/recebimentos.blade.php ENDPATH**/ ?>