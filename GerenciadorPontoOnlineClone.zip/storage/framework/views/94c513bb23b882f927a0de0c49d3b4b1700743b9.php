<div class="table-responsive">
    <table id="table-result" class="table table-dark table-hover">
        <?php if(isset($data) && sizeof($data) > 0): ?>
            <thead>
                <tr>
                    <?php $__currentLoopData = array_keys($data[0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collumn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="font-size-10"><?php echo e(strtoupper($collumn)); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $__currentLoopData = $line; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collumn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="font-size-10"><?php echo e($collumn); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        <?php endif; ?>
    </table>
</div>

<?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/layouts/table.blade.php ENDPATH**/ ?>