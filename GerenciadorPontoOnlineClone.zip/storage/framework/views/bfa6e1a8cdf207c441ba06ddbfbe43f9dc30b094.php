<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.forms.searchInRange', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-12 mx-auto" id="results">
        <hr class="">
        <?php if(isset($filters)): ?>
            <div id="filters" class="col-10 mx-auto text-center">
                <h5 class="font-weight-bold">Filtros Utilizados:</h5>
                <?php $__currentLoopData = array_keys($filters); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filterName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="badge badge-lg badge-info"><?php echo e($filterName); ?> : <?php echo e($filters[$filterName]); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if(isset($results)): ?>
            <?php echo e(view('layouts.table',['data'=>$results])); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.onlyhead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/layouts/consult.blade.php ENDPATH**/ ?>