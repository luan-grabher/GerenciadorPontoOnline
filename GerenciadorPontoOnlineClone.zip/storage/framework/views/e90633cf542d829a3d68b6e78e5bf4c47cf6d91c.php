<?php $__env->startSection('content'); ?>
    <iframe id="iframe-main" src="" class="h-100 w-100 border-0 overflow-auto">

    </iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/layouts/default.blade.php ENDPATH**/ ?>