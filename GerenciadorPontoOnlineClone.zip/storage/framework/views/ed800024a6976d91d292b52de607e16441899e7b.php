<?php if(isset($messages) && is_array($messages)): ?>
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($message['type']) && isset($message['text'])): ?>
            <div  class="alert alert-<?php echo e($message['type']); ?>"><?php echo e($message['text']); ?></div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\Dropbox\PHP\GerenciadorPontoOnlineClone\resources\views/layouts/messages.blade.php ENDPATH**/ ?>