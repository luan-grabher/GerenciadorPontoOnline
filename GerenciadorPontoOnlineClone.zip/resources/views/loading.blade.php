<div class="w-100 position-fixed text-center text-light bg-secondary shadow-lg d-none"
     style="z-index: 10000;opacity: 0.95"
     id="progress">
    <div class="p-2">
        CARREGANDO...
        <div class="spinner-border text-light" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

</div>
