@extends('layouts.onlyhead')
@section('content')
    @include('layouts.forms.searchInRange')
@endsection
