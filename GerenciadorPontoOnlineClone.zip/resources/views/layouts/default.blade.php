@extends('layouts.app')
@section('content')
    <iframe id="iframe-main" src="" class="h-100 w-100 border-0 overflow-auto">

    </iframe>
@endsection
