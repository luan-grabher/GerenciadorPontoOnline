<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="h-100">
@include('head')
<body class="">
    @yield('content')
</body>
</html>
